/*document.querySelector(".firstsection").computedStyleMap.setProperty("--height",window.innerHeight + "px");*/


function showSidebar(){
const sidebar = document.querySelector(".sidebar");
    sidebar.style.display="flex"
};

function hideSidebar(){
    const sidebar=document.querySelector(".sidebar");
    sidebar.style.display="none"
  };

  const slides=document.querySelectorAll(".slide");
  var counter=0;
   slides.forEach (
    (slide,index)=>{
    slide.style.left=`${index * 100}%`
     }
    )
    const goPrev=()=>{
      counter--;
      slideImage()
    }
    const goNext=()=>{
      counter++;
      slideImage()
    }
    const slideImage=()=>{
      slides.forEach(
        (slide)=>{
          slide.style.transform=`translateX(-${counter * 100}%)`
        
        }
      )
    }